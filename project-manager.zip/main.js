// 主入口脚本，使用动态导入实现代码拆分和懒加载

// 全局变量
window.projects = [];
window.recycleBin = [];
window.editingId = null;
window.currentEditProjectId = null;
window.statsFilter = 'thisYear'; // all 或 thisYear
window.db = null;
window.DEBUG = false;

// 动态导入各个模块
async function loadModules() {
  try {
    // 加载数据库模块
    const { default: dbModule } = await import('./db.js');
    window.db = dbModule;
    
    // 加载项目管理模块
    const projectModule = await import('./project-module.js');
    Object.assign(window, projectModule);
    
    // 加载渲染模块
    const renderModule = await import('./render-module.js');
    Object.assign(window, renderModule);
    
    // 加载AI模块
    const aiModule = await import('./ai-module.js');
    Object.assign(window, aiModule);
    
    // 加载文件系统模块
    const fsModule = await import('./file-system-module.js');
    Object.assign(window, fsModule);
    
    console.log('模块加载成功');
    return true;
  } catch (error) {
    console.error('模块加载失败:', error);
    return false;
  }
}

// 初始化应用
async function initApp() {
  try {
    // 加载所有模块
    const loadSuccess = await loadModules();
    
    if (loadSuccess) {
      // 初始化数据库
      await window.initDatabase();
    } else {
      // 模块加载失败，显示错误信息
      showToast('模块加载失败，请刷新页面重试');
    }
  } catch (error) {
    console.error('初始化应用失败:', error);
    showToast('初始化失败，请刷新页面重试');
  }
}

// 页面加载时初始化应用
window.addEventListener('DOMContentLoaded', initApp);
