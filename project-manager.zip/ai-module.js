// AI 相关功能模块

// AI 缓存配置
const AI_CACHE_CONFIG = {
  maxSize: 1000, // 最大缓存条目数
  expiryTime: 7 * 24 * 60 * 60 * 1000, // 缓存过期时间（7天）
};

// 在这里加上：
const AI_CACHE_KEY = 'ai_file_classify_cache';

// AI 调用配置
const AI_CALL_CONFIG = {
  maxRetries: 3, // 最大重试次数
  retryDelay: 1000, // 重试延迟（ms）
  batchSize: 20, // 批量处理大小
};

// ── 多 Provider 管理 ──────────────────────
const PROVIDER_LIST_KEY = 'pmAiProviders';
const TASK_SLOTS_KEY    = 'pmAiTaskSlots';

const TASK_SLOT_DEFS = {
  default:  { label: '默认模型',      desc: '未单独配置的任务',         icon: '🤖' },
  document: { label: '文档解析',      desc: '语雀导入、列名识别',        icon: '📄' },
  contract: { label: '合同/协议识别', desc: '文字型 PDF 识别',           icon: '📝' },
  vision:   { label: '图像识别',      desc: '扫描件 PDF、图片',          icon: '🖼️' },
  advanced: { label: '复杂推理',      desc: '台账筛选等长上下文任务',    icon: '🧠' },
};

const TASK_TO_SLOT = {
  '合同文本解析':     'contract',
  '合同PDF解析':      'contract',
  '合同扫描件识别':   'vision',
  '技术协议PDF解析':  'contract',
  '方案报价PDF解析':  'contract',
  '语雀文档解析':     'document',
  '语雀表格列名识别': 'document',
  '进度列识别':       'document',
  '台账AI筛选':       'advanced',
  '文件名分类':       'default',
  '对话测试':         'default',
  'API连接测试':      'default',
};

// 加载 AI 配置（向后兼容）
function getAiConfig() {
  return {
    provider:    localStorage.getItem(window.STORAGE_KEY.AI_PROVIDER)     || 'claude',
    model:       localStorage.getItem(window.STORAGE_KEY.AI_MODEL)        || 'claude-haiku-4-5-20251001',
    proxy:       (localStorage.getItem(window.STORAGE_KEY.AI_PROXY)       || '').replace(/\/+$/, ''),
    key:         localStorage.getItem(window.STORAGE_KEY.AI_KEY)          || '',
    modelPolicy: localStorage.getItem(window.STORAGE_KEY.AI_MODEL_POLICY) || 'auto',
    maxTokens:   parseInt(localStorage.getItem(window.STORAGE_KEY.AI_MAX_TOKENS)) || 2000};
}

// 保存 AI 配置
function saveAiProxy(v)       { try { localStorage.setItem(window.STORAGE_KEY.AI_PROXY, v.trim()); } catch(e) {} }
function saveAiKey(v)         { try { localStorage.setItem(window.STORAGE_KEY.AI_KEY, v.trim()); } catch(e) {} }
function saveAiModel(v)       { try { localStorage.setItem(window.STORAGE_KEY.AI_MODEL, v); } catch(e) {} }
function saveAiProvider(v)    { try { localStorage.setItem(window.STORAGE_KEY.AI_PROVIDER, v); } catch(e) {} }
function saveModelPolicy(v)   { try { localStorage.setItem(window.STORAGE_KEY.AI_MODEL_POLICY, v); } catch(e) {} }
function saveAiMaxTokens(v)   { try { localStorage.setItem(window.STORAGE_KEY.AI_MAX_TOKENS, parseInt(v) || 2000); } catch(e) {} }

function getProviderList() {
  try {
    const data = localStorage.getItem(PROVIDER_LIST_KEY);
    if (data) return JSON.parse(data);
  } catch(e) {}
  const cfg = getAiConfig();
  return [{ id: 'default', name: '默認配置', type: cfg.provider, proxy: cfg.proxy, key: cfg.key, model: cfg.model, maxTokens: cfg.maxTokens, supportsVision: _inferVision(cfg.provider, cfg.model) }];
}

function saveProviderList(list) { try { localStorage.setItem(PROVIDER_LIST_KEY, JSON.stringify(list)); } catch(e) {} }

function getTaskSlots() {
  try { const d = localStorage.getItem(TASK_SLOTS_KEY); if (d) return JSON.parse(d); } catch(e) {}
  return { default: 'default', document: 'default', contract: 'default', vision: 'default', advanced: 'default' };
}

function saveTaskSlots(slots) { try { localStorage.setItem(TASK_SLOTS_KEY, JSON.stringify(slots)); } catch(e) {} }

function _inferVision(type, model) {
  if (type === 'claude' || type === 'gemini') return true;
  if (type === 'openai' && model && (model.includes('gpt-4o') || model.includes('vision'))) return true;
  if (type === 'custom') {
    const m = (model || '').toLowerCase();
    if (m.includes('glm-4v') || m.includes('glm-4.5v') || m.includes('glm-4.6v') || m.includes('vision') || m.includes('vl') || m.includes('kimi') || m.includes('moonshot')) return true;
  }
  return false;
}

function getProviderForTask(task) {
  const slotId = TASK_TO_SLOT[task] || 'default';
  const slots  = getTaskSlots();
  const pid    = slots[slotId] || slots['default'] || 'default';
  const list   = getProviderList();
  return list.find(p => p.id === pid) || list[0] || null;
}

function _buildCallParams(entry) {
  const type = entry.type || 'custom';
  const provider = AI_PROVIDERS[type] || AI_PROVIDERS.custom;
  const proxy = (entry.proxy || '').replace(/\/+$/, '');
  const model = entry.model || '', key = entry.key || '', maxTokens = entry.maxTokens || 2000;
  let endpoint;
  if (type === 'custom') { endpoint = proxy.endsWith('/chat/completions') ? proxy : proxy + '/chat/completions'; }
  else { endpoint = typeof provider.endpoint === 'function' ? provider.endpoint(proxy, model, key) : provider.endpoint; }
  return { provider, endpoint, model, key, proxy, maxTokens };
}

function _pushLog(log) {
  aiLogs.unshift(log);
  if (aiLogs.length > 200) aiLogs = aiLogs.slice(0, 200);
  try { localStorage.setItem(window.STORAGE_KEY.AI_LOGS, JSON.stringify(aiLogs)); } catch(e) {}
}

async function _doCall({ task, max_tokens, messages, entry }) {
  const t0 = Date.now();
  const { provider, endpoint, model, key, proxy, maxTokens } = _buildCallParams(entry);
  const log = { id: Date.now(), time: new Date().toLocaleString(), task, model, provider: entry.type, in: 0, out: 0, dur: 0, status: 'ok', error: '' };
  try {
    const resp = await fetch(endpoint, { method: 'POST', headers: provider.buildHeaders(key, proxy), body: JSON.stringify(provider.buildBody(model, max_tokens || maxTokens, messages)) });
    const data = await resp.json();
    log.dur = ((Date.now() - t0) / 1000).toFixed(2);
    const parsed = provider.parseResponse(data);
    if (parsed.usage) { log.in = parsed.usage.input_tokens || 0; log.out = parsed.usage.output_tokens || 0; }
    if (!resp.ok || parsed.error) { log.status = 'err'; log.error = parsed.error || `HTTP ${resp.status}`; }
    _pushLog(log); return { ...data, _parsed: parsed };
  } catch(e) { log.dur = ((Date.now() - t0) / 1000).toFixed(2); log.status = 'err'; log.error = e.message; _pushLog(log); throw e; }
}

async function _doVisionCall({ task, max_tokens, images, textPrompt, entry }) {
  const t0 = Date.now();
  const { provider, endpoint, model, key, proxy, maxTokens } = _buildCallParams(entry);
  const log = { id: Date.now(), time: new Date().toLocaleString(), task, model, provider: entry.type, in: 0, out: 0, dur: 0, status: 'ok', error: '' };
  const type = entry.type;
  let body;
  if (type === 'claude') {
    body = { model, max_tokens: max_tokens || maxTokens, messages: [{ role: 'user', content: [...images.map(img => ({ type: 'image', source: { type: 'base64', media_type: img.mimeType, data: img.base64 } })), { type: 'text', text: textPrompt }] }] };
  } else if (type === 'gemini') {
    body = { contents: [{ role: 'user', parts: [...images.map(img => ({ inline_data: { mime_type: img.mimeType, data: img.base64 } })), { text: textPrompt }] }], generationConfig: { maxOutputTokens: max_tokens || maxTokens } };
  } else {
    body = { model, max_tokens: max_tokens || maxTokens, messages: [{ role: 'user', content: [...images.map(img => ({ type: 'image_url', image_url: { url: `data:${img.mimeType};base64,${img.base64}` } })), { type: 'text', text: textPrompt }] }] };
  }
  try {
    const resp = await fetch(endpoint, { method: 'POST', headers: provider.buildHeaders(key, proxy), body: JSON.stringify(body) });
    const data = await resp.json();
    log.dur = ((Date.now() - t0) / 1000).toFixed(2);
    const parsed = provider.parseResponse(data);
    if (parsed.usage) { log.in = parsed.usage.input_tokens || 0; log.out = parsed.usage.output_tokens || 0; }
    if (!resp.ok || parsed.error) { log.status = 'err'; log.error = parsed.error || `HTTP ${resp.status}`; }
    _pushLog(log); return { ...data, _parsed: parsed };
  } catch(e) { log.dur = ((Date.now() - t0) / 1000).toFixed(2); log.status = 'err'; log.error = e.message; _pushLog(log); throw e; }
}

async function sendProviderChatTest() {
  const input = document.getElementById('ape-chat-input');
  const msg = input.value.trim();
  if (!msg) return;
  input.value = '';

  const history = document.getElementById('ape-chat-history');
  const placeholder = history.querySelector('div[style*="color:#999"]');
  if (placeholder) placeholder.remove();

  // 获取当前编辑的模型ID
  const overlay = document.getElementById('ai-provider-editor');
  const modelId = overlay ? overlay.dataset.editId : 'default';

  // 确保该模型的对话历史存在
  if (!window.chatTestHistory[modelId]) {
    window.chatTestHistory[modelId] = [];
  }

  // 添加用户消息到历史
  window.chatTestHistory[modelId].push({ role: 'user', content: msg });

  // 添加用户消息到界面
  const userBubble = document.createElement('div');
  userBubble.style.cssText = 'background:rgba(79,70,229,.15);border:1px solid rgba(79,70,229,.25);border-radius:8px 8px 8px 0;padding:8px 12px;align-self:flex-start;max-width:80%;font-size:.7rem;line-height:1.4;color:#ffffff';
  userBubble.textContent = msg;
  history.appendChild(userBubble);

  // 添加 AI 思考消息
  const thinkBubble = document.createElement('div');
  thinkBubble.style.cssText = 'background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.15);border-radius:8px 8px 0 8px;padding:8px 12px;align-self:flex-end;max-width:80%;font-size:.7rem;line-height:1.4;color:#ffffff';
  thinkBubble.textContent = '思考中…';
  history.appendChild(thinkBubble);
  history.scrollTop = history.scrollHeight;

  // 获取当前编辑的 Provider 配置
  const type  = document.querySelector('.ape-type-btn.active')?.dataset.type || 'custom';
  const proxy = document.getElementById('ape-proxy').value.trim();
  const key   = document.getElementById('ape-key').value.trim();
  const model = document.getElementById('ape-model').value.trim();
  const maxTokens = parseInt(document.getElementById('ape-tokens').value) || 4000;

  try {
    const result = await _doCall({ 
      task: '对话测试', 
      max_tokens: 800, 
      messages: [{ role: 'user', content: msg }], 
      entry: { id: '_test', name: '测试', type, proxy, key, model, maxTokens } 
    });
    const reply = result._parsed?.text || '';
    thinkBubble.textContent = reply || '（空响应）';
    // 添加 AI 回复到历史
    window.chatTestHistory[modelId].push({ role: 'assistant', content: reply || '（空响应）'});
  } catch(e) {
    thinkBubble.style.color = '#e57373';
    thinkBubble.textContent = '❌ ' + e.message;
    // 添加错误信息到历史
    window.chatTestHistory[modelId].push({ role: 'assistant', content: '❌ ' + e.message});
  } finally {
    history.scrollTop = history.scrollHeight;
  }
}

async function claudeCallForTask({ task, max_tokens, messages }) {
  const entry = getProviderForTask(task);
  if (!entry) throw new Error('未找到可用的 AI 配置');
  return _doCall({ task, max_tokens, messages, entry });
}

async function claudeCallWithVisionForTask({ task, max_tokens, images, textPrompt }) {
  const slots = getTaskSlots();
  const pid   = slots['vision'] || slots['default'] || 'default';
  const list  = getProviderList();
  const entry = list.find(p => p.id === pid) || list[0];
  if (!entry) throw new Error('未找到图像识别配置');
  if (!entry.supportsVision && !_inferVision(entry.type, entry.model)) {
    throw new Error(`当前图像识别模型（${entry.name}）不支持图片输入，请在 AI 控制台配置支持视觉的模型`);
  }
  return _doVisionCall({ task, max_tokens, images, textPrompt, entry });
}


// ╔══════════════════════════════════════════╗
// ║  MODULE: ai-service（AI 调用层）          ║
// ╚══════════════════════════════════════════╝

const AI_PROVIDERS = {
  claude: {
    name: 'Claude', icon: '🤖',
    endpoint: (proxy) => proxy ? `${proxy}/claude/v1/messages` : 'https://api.anthropic.com/v1/messages',
    models: [
      { id: 'claude-haiku-4-5-20251001', label: 'Claude Haiku 4.5（快速）' },
      { id: 'claude-sonnet-4-20250514',  label: 'Claude Sonnet 4（均衡）' },
      { id: 'claude-opus-4-20250514',    label: 'Claude Opus 4（最强）' },
    ],
    buildHeaders: (key, proxy) => {
      const h = { 'Content-Type': 'application/json', 'anthropic-version': '2023-06-01' };
      if (key) h['x-api-key'] = key;
      if (!proxy) h['anthropic-dangerous-direct-browser-access'] = 'true';
      return h;
    },
    buildBody: (model, max_tokens, messages) => ({ model, max_tokens, messages }),
    parseResponse: (data) => ({
      text:  data.content?.filter(b => b.type === 'text').map(b => b.text).join('') || '',
      usage: data.usage,
      error: data.error?.message
    })
  },
  openai: {
    name: 'OpenAI', icon: '✨',
    endpoint: (proxy) => proxy ? `${proxy}/openai/v1/chat/completions` : 'https://api.openai.com/v1/chat/completions',
    models: [
      { id: 'gpt-4o-mini', label: 'GPT-4o Mini（快速）' },
      { id: 'gpt-4o',      label: 'GPT-4o（均衡）' },
      { id: 'o1-mini',     label: 'o1 Mini（推理）' },
    ],
    buildHeaders: (key) => ({ 'Content-Type': 'application/json', 'Authorization': `Bearer ${key}` }),
    buildBody: (model, max_tokens, messages) => ({
      model, max_tokens,
      messages: messages.map(m => ({
        role: m.role,
        content: Array.isArray(m.content) ? m.content.map(c => c.text || '').join('') : m.content
      }))
    }),
    parseResponse: (data) => ({
      text:  data.choices?.[0]?.message?.content || '',
      usage: data.usage ? { input_tokens: data.usage.prompt_tokens, output_tokens: data.usage.completion_tokens } : null,
      error: data.error?.message
    })
  },
  gemini: {
    name: 'Gemini', icon: '💎',
    endpoint: (proxy, model, key) => proxy
      ? `${proxy}/gemini/v1beta/models/${model}:generateContent`
      : `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${key}`,
    models: [
      { id: 'gemini-2.0-flash',      label: 'Gemini 2.0 Flash（快速）' },
      { id: 'gemini-2.5-pro-preview', label: 'Gemini 2.5 Pro（最强）' },
    ],
    buildHeaders: (key, proxy) => {
      const h = { 'Content-Type': 'application/json' };
      if (proxy && key) h['x-goog-api-key'] = key;
      return h;
    },
    buildBody: (model, max_tokens, messages) => ({
      contents: messages.map(m => ({
        role:  m.role === 'assistant' ? 'model' : 'user',
        parts: [{ text: Array.isArray(m.content) ? m.content.map(c => c.text || '').join('') : m.content }]
      })),
      generationConfig: { maxOutputTokens: max_tokens }
    }),
    parseResponse: (data) => ({
      text:  data.candidates?.[0]?.content?.parts?.map(p => p.text || '').join('') || '',
      usage: data.usageMetadata
        ? { input_tokens: data.usageMetadata.promptTokenCount, output_tokens: data.usageMetadata.candidatesTokenCount }
        : null,
      error: data.error?.message
    })
  },
  custom: {
    name: '自定义', icon: '🔧',
    endpoint: (proxy) => proxy || '',
    models: [{ id: '', label: '请在下方输入模型名称' }],
    buildHeaders: (key) => ({ 'Content-Type': 'application/json', 'Authorization': `Bearer ${key}` }),
    buildBody: (model, max_tokens, messages) => ({
      model, max_tokens,
      messages: messages.map(m => ({
        role: m.role,
        content: Array.isArray(m.content) ? m.content.map(c => c.text || '').join('') : m.content
      }))
    }),
    parseResponse: (data) => {
      const choice    = data.choices?.[0];
      const content   = choice?.message?.content || '';
      const truncated = choice?.finish_reason === 'length';
      return {
        text:  content,
        usage: data.usage
          ? { input_tokens: data.usage.prompt_tokens || data.usage.input_tokens || 0, output_tokens: data.usage.completion_tokens || data.usage.output_tokens || 0 }
          : null,
        error: data.error?.message || (truncated ? '输出被截断（token 不足），请在模型配置中调大 max_tokens' : undefined)
      };
    }
  }
};

// 快速任务用小模型，复杂任务用高级模型
const TASK_MODEL_OVERRIDE = {
  '合同文本解析': 'advanced',
  '合同PDF解析':  'advanced',
  '语雀文档解析': 'advanced',
  '台账AI筛选':   'advanced'
};

// 自定义服务商的路由前缀（通过 Worker 转发）
const CUSTOM_ROUTE = '/custom';

// AI 调用日志
let aiLogs = [];
try { aiLogs = JSON.parse(localStorage.getItem(window.STORAGE_KEY.AI_LOGS) || '[]'); } catch(e) { aiLogs = []; }

// 对话测试历史（按模型配置ID存储）
window.chatTestHistory = {};

// claudeCall：优先用任务槽位系统，兜底用旧配置
async function claudeCall({ task, model, max_tokens, messages }) {
  const entry = getProviderForTask(task);
  if (entry) return _doCall({ task, max_tokens, messages, entry });
  // 兜底：旧配置
  const t0 = Date.now(), cfg = getAiConfig();
  const provider = AI_PROVIDERS[cfg.provider] || AI_PROVIDERS.claude;
  let usedModel = cfg.model;
  if (cfg.modelPolicy === 'auto' && TASK_MODEL_OVERRIDE[task] === 'advanced' && cfg.provider !== 'custom') {
    usedModel = provider.models[provider.models.length - 1].id;
  }
  const log = { id: Date.now(), time: new Date().toLocaleString(), task, model: usedModel, provider: cfg.provider, in: 0, out: 0, dur: 0, status: 'ok', error: '' };
  let endpoint;
  if (cfg.provider === 'custom') { const base = cfg.proxy.replace(/\/+$/, ''); endpoint = base.endsWith('/chat/completions') ? base : base + '/chat/completions'; }
  else { endpoint = typeof provider.endpoint === 'function' ? provider.endpoint(cfg.proxy, usedModel, cfg.key) : provider.endpoint; }
  try {
    const resp = await fetch(endpoint, { method: 'POST', headers: provider.buildHeaders(cfg.key, cfg.proxy), body: JSON.stringify(provider.buildBody(usedModel, max_tokens || cfg.maxTokens, messages)) });
    const data = await resp.json(); log.dur = ((Date.now() - t0) / 1000).toFixed(2);
    const parsed = provider.parseResponse(data);
    if (parsed.usage) { log.in = parsed.usage.input_tokens || 0; log.out = parsed.usage.output_tokens || 0; }
    if (!resp.ok || parsed.error) { log.status = 'err'; log.error = parsed.error || `HTTP ${resp.status}`; }
    _pushLog(log); return { ...data, _parsed: parsed };
  } catch(e) { log.dur = ((Date.now() - t0) / 1000).toFixed(2); log.status = 'err'; log.error = e.message; _pushLog(log); throw e; }
}

// 向后兼容：判断视觉槽位是否支持图片
function providerSupportsVision() {
  const slots = getTaskSlots(), list = getProviderList();
  const entry = list.find(p => p.id === (slots['vision'] || slots['default'])) || list[0];
  return !!(entry && (entry.supportsVision || _inferVision(entry.type, entry.model)));
}

function getProviderName() {
  const cfg = getAiConfig();
  return (AI_PROVIDERS[cfg.provider] || {}).name || cfg.provider;
}

// 向后兼容：视觉调用走 vision 槽位
async function claudeCallWithVision({ task, max_tokens, images, textPrompt }) {
  return claudeCallWithVisionForTask({ task, max_tokens, images, textPrompt });
}

function clearAiLogs() {
  aiLogs = [];
  try { localStorage.removeItem(window.STORAGE_KEY.AI_LOGS); } catch(e) {}
}

function getAiLogs() {
  return aiLogs;
}

// AI 分类缓存
let aiClassificationCache = {};

// 会话级文件分类缓存
const fileClassifyCache = new Map();

// 加载 AI 分类缓存
function loadAiClassificationCache() {
  try {
    const cached = localStorage.getItem(AI_CACHE_KEY);
    if (cached) {
      const parsed = JSON.parse(cached);
      const now = Date.now();
      // 清理过期缓存
      aiClassificationCache = {};
      Object.entries(parsed).forEach(([key, value]) => {
        if (value.timestamp && (now - value.timestamp) < AI_CACHE_CONFIG.expiryTime) {
          aiClassificationCache[key] = value.data;
        }
      });
      // 保存清理后的缓存
      if (Object.keys(aiClassificationCache).length < Object.keys(parsed).length) {
        saveAiClassificationCache();
      }
    }
  } catch (error) {
    if (DEBUG) console.error('加载 AI 分类缓存失败：', error);
    aiClassificationCache = {};
  }
}

// 保存 AI 分类缓存
function saveAiClassificationCache() {
  try {
    // 限制缓存大小
    const entries = Object.entries(aiClassificationCache);
    if (entries.length > AI_CACHE_CONFIG.maxSize) {
      // 保留最新的缓存条目
      const sorted = entries.sort((a, b) => {
        const timeA = a[1].timestamp || 0;
        const timeB = b[1].timestamp || 0;
        return timeB - timeA;
      });
      const trimmed = sorted.slice(0, AI_CACHE_CONFIG.maxSize);
      const newCache = {};
      trimmed.forEach(([key, value]) => {
        newCache[key] = value;
      });
      aiClassificationCache = newCache;
    }
    
    // 保存到本地存储
    localStorage.setItem(AI_CACHE_KEY, JSON.stringify(aiClassificationCache));
  } catch (error) {
    if (DEBUG) console.error('保存 AI 分类缓存失败：', error);
  }
}

// 清理 AI 分类缓存
function clearAiClassificationCache() {
  aiClassificationCache = {};
  try {
    localStorage.removeItem(AI_CACHE_KEY);
  } catch (error) {
    if (DEBUG) console.error('清理 AI 分类缓存失败：', error);
  }
}

// 防抖处理的 AI 分类函数
const debouncedClassifyFileNames = debounce(async function(names) {
  if (!names.length) return {};
  const TAG_MAP = {
    '合同':     { label:'合同',   cls:'tag-contract',  cat:'合同'     },
    '技术协议': { label:'技术协议',cls:'tag-agreement', cat:'技术协议' },
    '报价':     { label:'报价单', cls:'tag-quote',      cat:'报价'     },
    '发票':     { label:'发票',   cls:'tag-invoice',    cat:'发票'     },
    '其他':     { label:'其他',   cls:'tag-other',      cat:'其他'     }};

  // 关键词规则预匹配（优先于AI）
  const KEYWORD_RULES = [
    { keywords: ['合同','采购合同','销售合同','框架协议','购销合同'], cat: '合同' },
    { keywords: ['技术协议','技术方案','需求文档','技术规范','技术要求','规格书'], cat: '技术协议' },
    { keywords: ['报价','询价','报价单','报价表'], cat: '报价' },
    { keywords: ['发票','收据','收款'], cat: '发票' },
  ];

  const result = {};
  const needAi = [];

  for (const name of names) {
    // 1. 优先从缓存中获取
    if (aiClassificationCache[name]) {
      result[name] = aiClassificationCache[name].data || aiClassificationCache[name];
      continue;
    }

    // 2. 关键词规则预匹配
    let matched = false;
    for (const rule of KEYWORD_RULES) {
      if (rule.keywords.some(kw => name.includes(kw))) {
        result[name] = TAG_MAP[rule.cat];
        // 缓存结果（带时间戳）
        aiClassificationCache[name] = {
          data: TAG_MAP[rule.cat],
          timestamp: Date.now()
        };
        matched = true;
        break;
      }
    }
    if (!matched) needAi.push(name);
  }

  // 3. 剩余文件交给 AI 判断（批量处理）
  if (needAi.length) {
    // 分批处理文件
    const batches = [];
    for (let i = 0; i < needAi.length; i += AI_CALL_CONFIG.batchSize) {
      batches.push(needAi.slice(i, i + AI_CALL_CONFIG.batchSize));
    }
    
    for (const batch of batches) {
      try {
        // 带重试机制的 AI 调用
        let data;
        for (let retry = 0; retry < AI_CALL_CONFIG.maxRetries; retry++) {
          try {
            data = await claudeCall({
              task: '文件名分类',
              max_tokens: 600,
              messages: [{ role: 'user', content: `以下是项目文件夹中的文件名列表：\n${JSON.stringify(batch)}\n\n请判断每个文件名属于哪个类别，只能从以下类别中选择：\n- 合同（正式合同、框架协议等）\n- 技术协议（技术协议、技术方案、需求文档等）\n- 报价（报价单、询价单等）\n- 发票（发票、收据等）\n- 其他\n\n只返回JSON对象，key是文件名，value是类别。` }]
            });
            break; // 成功，退出重试循环
          } catch (e) {
            if (DEBUG) console.error(`AI 分类失败（重试 ${retry + 1}/${AI_CALL_CONFIG.maxRetries}）：`, e);
            if (retry < AI_CALL_CONFIG.maxRetries - 1) {
              await new Promise(resolve => setTimeout(resolve, AI_CALL_CONFIG.retryDelay));
            }
          }
        }
        
        if (data) {
          const text = data._parsed?.text || data.content?.[0]?.text || '';
          const match = text.match(/\{[\s\S]*\}/);
          if (match) {
            const raw = JSON.parse(match[0]);
            for (const [name, cat] of Object.entries(raw)) {
              result[name] = TAG_MAP[cat] || TAG_MAP['其他'];
              // 缓存结果（带时间戳）
              aiClassificationCache[name] = {
                data: TAG_MAP[cat] || TAG_MAP['其他'],
                timestamp: Date.now()
              };
            }
          }
        }
      } catch(e) {
        if (DEBUG) console.error('AI 分类失败：', e);
      }
    }
    
    // AI 未返回的文件标为其他
    for (const name of needAi) {
      if (!result[name]) {
        result[name] = TAG_MAP['其他'];
        // 缓存结果（带时间戳）
        aiClassificationCache[name] = {
          data: TAG_MAP['其他'],
          timestamp: Date.now()
        };
      }
    }
    
    // 保存缓存
    saveAiClassificationCache();
  }

  return result;
}, 500); // 500ms 防抖

// 导出的分类函数
async function classifyFileNames(names) {
  // 首先从会话级缓存中获取结果
  const cachedResults = {};
  const uncachedNames = [];
  
  for (const name of names) {
    if (fileClassifyCache.has(name)) {
      cachedResults[name] = fileClassifyCache.get(name);
    } else {
      uncachedNames.push(name);
    }
  }
  
  // 只对未缓存的文件名进行处理
  if (uncachedNames.length > 0) {
    // 确保持久化缓存已加载
    if (Object.keys(aiClassificationCache).length === 0) {
      loadAiClassificationCache();
    }
    
    // 调用防抖的分类函数处理未缓存的文件名
    const newResults = await debouncedClassifyFileNames(uncachedNames);
    
    // 将新结果写入会话级缓存
    for (const [name, result] of Object.entries(newResults)) {
      fileClassifyCache.set(name, result);
    }
    
    // 合并缓存结果和新结果
    return { ...cachedResults, ...newResults };
  }
  
  // 所有结果都在缓存中
  return cachedResults;
}

// 导出模块
export {
  // AI 配置（向后兼容）
  getAiConfig,
  saveAiProxy,
  saveAiKey,
  saveAiModel,
  saveAiProvider,
  saveModelPolicy,
  saveAiMaxTokens,
  // 多 Provider 管理
  getProviderList,
  saveProviderList,
  getTaskSlots,
  saveTaskSlots,
  TASK_SLOT_DEFS,
  TASK_TO_SLOT,
  _inferVision,
  _doCall,
  // AI 服务商
  AI_PROVIDERS,
  TASK_MODEL_OVERRIDE,
  CUSTOM_ROUTE,
  // AI 调用
  claudeCall,
  claudeCallForTask,
  claudeCallWithVision,
  claudeCallWithVisionForTask,
  providerSupportsVision,
  getProviderName,
  aiLogs,
  clearAiLogs,
  getAiLogs,
  sendProviderChatTest,
  // 文件分类
  classifyFileNames,
  clearAiClassificationCache
};
