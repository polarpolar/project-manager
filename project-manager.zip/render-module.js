// ╔══════════════════════════════════════════╗
// ║  MODULE: render-board（看板视图层）       ║
// ╚══════════════════════════════════════════╝

// 卡片 HTML 缓存（key = projectId_colKey_updatedAt）
const renderCache = new Map();

// ── render() ──────────────────────────────────────
// 同步渲染四列看板，用 DocumentFragment 减少回流。
// 不使用 setTimeout / requestAnimationFrame 分批，
// 对几十个项目的规模一次性渲染反而更快。
function render() {
  // 筛选按钮高亮
  const buttons = document.querySelectorAll('.sb-stats-title button');
  buttons.forEach(btn => {
    const isActive = btn.onclick.toString().includes(statsFilter);
    btn.style.background = isActive ? 'var(--gold)' : 'none';
    btn.style.color      = isActive ? 'var(--ink)'  : 'rgba(255,255,255,.72)';
  });

  // 按列分组
  const cols = { '0':[], '1':[], '2':[], '3':[] };
  projects.forEach(p => cols[getBoardColumn(p)].push(p));

  // 渲染每列
  ['0','1','2','3'].forEach(key => {
    const body  = document.getElementById('col'   + key);
    const badge = document.getElementById('badge' + key);
    const pipe  = document.getElementById('pipe'  + key);

    if (badge) badge.textContent = cols[key].length;
    if (pipe)  pipe.textContent  = cols[key].length;

    if (!body) return;

    // DocumentFragment 批量写入，只触发一次回流
    const fragment = document.createDocumentFragment();
    const wrapper  = document.createElement('div');
    wrapper.innerHTML = cols[key].length
      ? cols[key].map(p => cardHTML(p, key)).join('')
      : '<div class="empty-state">暂无项目</div>';
    while (wrapper.firstChild) fragment.appendChild(wrapper.firstChild);
    body.innerHTML = '';
    body.appendChild(fragment);
  });

  updateStats();
}

// ── updateStats() ─────────────────────────────────
function updateStats() {
  const statTotal    = document.getElementById('stat-total');
  const statQuote    = document.getElementById('stat-quote');
  const statContract = document.getElementById('stat-contract');
  const statTodo     = document.getElementById('stat-todo');
  if (!statTotal || !statQuote || !statContract || !statTodo) return;

  const thisYear = new Date().getFullYear();

  const filteredProjects = statsFilter === 'thisYear'
    ? projects.filter(p => {
        if (!p.contractDate) return false;
        return new Date(p.contractDate).getFullYear() === thisYear;
      })
    : projects.filter(p => {
        if (p.stage === STAGE.NEGOTIATING) return true;
        if (p.contractDate) return new Date(p.contractDate).getFullYear() === thisYear;
        return false;
      });

  const totalCount  = projects.length;
  const quoteSum    = projects.filter(p => p.stage === STAGE.NEGOTIATING)
                              .reduce((a, p) => a + (parseFloat(p.quote) || 0), 0);
  const contractSum = filteredProjects.reduce((a, p) => a + (parseFloat(p.contract) || 0), 0);
  const todoCount   = filteredProjects.reduce((a, p) => a + (p.todos || []).filter(t => !t.done).length, 0);

  statTotal.textContent    = totalCount;
  statQuote.textContent    = quoteSum.toFixed(2);
  statContract.textContent = contractSum.toFixed(2);
  statTodo.textContent     = todoCount;
}

// ── cardHTML() ────────────────────────────────────
function cardHTML(p, colKey) {
  // 缓存：同一项目、同一列、同一 updatedAt → 直接返回
  const cacheKey = `${p.id}_${colKey}_${p.updatedAt || ''}`;
  if (renderCache.has(cacheKey)) return renderCache.get(cacheKey);

  const sAttr = colKey === 'c' ? 'c' : STAGE_S_ATTR[p.stage];

  const metaHtml = (p.channel || p.source || p.owner || p.product || (p.stage === STAGE.NEGOTIATING && p.洽谈状态)) ? `
    <div class="card-meta">
      ${p.channel ? `<span class="card-tag">🌐 ${esc(p.channel)}</span>` : ''}
      ${p.source  ? `<span class="card-tag">📌 ${esc(p.source)}</span>`  : ''}
      ${p.owner   ? `<span class="card-tag">👤 ${esc(p.owner)}</span>`   : ''}
      ${p.product ? `<span class="card-tag">📦 ${esc(p.product)}</span>` : ''}
      ${p.stage === STAGE.NEGOTIATING && p.洽谈状态 ? `<span class="card-tag">💬 ${esc(p.洽谈状态)}</span>` : ''}
    </div>` : '';

  const amtHtml = (p.quote || p.contract || p.cost) && p.stage === STAGE.NEGOTIATING ? `
    <div class="card-amounts">
      ${p.quote    ? `<div class="amount-item"><div class="alabel">报价</div><div class="aval">¥${fmtWanShort(p.quote)}万</div></div>`             : ''}
      ${p.contract ? `<div class="amount-item"><div class="alabel">合同</div><div class="aval contract">¥${fmtWanShort(p.contract)}万</div></div>` : ''}
      ${p.cost     ? `<div class="amount-item"><div class="alabel">成本</div><div class="aval cost">¥${fmtWanShort(p.cost)}万</div></div>`         : ''}
    </div>` : '';

  // 交付标签（交付中/已完结显示）
  const tags = p.deliveryTags || {};
  const tagItems = [
    tags.wireless_hardware && `<span style="font-size:.62rem;padding:2px 8px;border-radius:10px;background:rgba(21,101,192,.1);color:#1565c0;font-weight:600">📡 无线</span>`,
    tags.wired_hardware    && `<span style="font-size:.62rem;padding:2px 8px;border-radius:10px;background:rgba(46,125,50,.1);color:#2e7d32;font-weight:600">🔌 有线</span>`,
    tags.software          && `<span style="font-size:.62rem;padding:2px 8px;border-radius:10px;background:rgba(106,27,154,.1);color:#6a1b9a;font-weight:600">💻 软件</span>`,
    tags.other             && `<span style="font-size:.62rem;padding:2px 8px;border-radius:10px;background:rgba(230,81,0,.1);color:#e65100;font-weight:600">📎 其他</span>`,
  ].filter(Boolean);
  const hasDelivery = tagItems.length || p.deliveryBrief || p.deliveryNote;
  const deliveryHtml = (p.stage === STAGE.DELIVERING || p.stage === STAGE.COMPLETED) ? `
    <div style="margin:5px 0;padding:7px 10px;background:rgba(21,101,192,.04);border-radius:6px;border-left:2px solid var(--s1)">
      <div style="display:flex;align-items:center;gap:6px;margin-bottom:${hasDelivery ? '5px' : '0'}">
        <span style="font-size:.6rem;color:var(--s1);font-weight:600">📦 交付内容</span>
      </div>
      ${tagItems.length ? `<div style="display:flex;gap:4px;flex-wrap:wrap">${tagItems.join('')}</div>` : ''}
      ${!hasDelivery ? `<div style="font-size:.65rem;color:#bbb">暂无交付信息，可通过文件面板识别技术协议自动提取</div>` : ''}
    </div>` : '';

  // 回款进度 + 节点摘要
  let paymentHtml = '';
  if ((p.stage === STAGE.DELIVERING || p.stage === STAGE.COMPLETED) && p.contract) {
    const pct       = p.paymentPct || 0;
    const nodes     = p.paymentNodes || [];
    const doneCount = nodes.filter(n => n.done).length;
    const nodePreview = nodes.slice(0, 3).map(n => `
      <div style="display:flex;align-items:flex-start;gap:5px;padding:3px 0;border-bottom:1px solid var(--paper2);flex-wrap:wrap">
        <span style="width:12px;height:12px;border-radius:50%;border:1.5px solid ${n.done ? 'var(--sc)' : '#ddd'};background:${n.done ? 'var(--sc)' : 'transparent'};flex-shrink:0;display:flex;align-items:center;justify-content:center;margin-top:2px">
          ${n.done ? '<span style="color:#fff;font-size:8px">✓</span>' : ''}
        </span>
        <span style="font-size:.65rem;color:#666;flex:1;min-width:0;word-wrap:break-word">${esc(n.condition || '付款节点')}</span>
        ${n.ratio ? `<span style="font-size:.63rem;color:var(--sc);font-weight:700;flex-shrink:0;margin-top:2px">${n.ratio}</span>` : ''}
        ${n.contractAmountYuan
          ? `<span style="font-size:.62rem;color:#888;flex-shrink:0;margin-top:2px">${fmtYuan(n.contractAmountYuan)} 元</span>`
          : n.amount ? `<span style="font-size:.62rem;color:#888;flex-shrink:0;margin-top:2px">${n.amount}</span>` : ''}
      </div>`).join('');
    paymentHtml = `
    <div class="card-payment">
      <div class="card-payment-label">
        <span>💰 回款进度</span>
        <span>${pct}%${nodes.length ? ` · ${doneCount}/${nodes.length}节点` : ''}</span>
      </div>
      <div class="pbar-wrap"><div class="pbar-fill" style="width:${pct}%"></div></div>
      ${nodes.length ? `<div style="margin-top:5px">${nodePreview}${nodes.length > 3 ? `<div style="font-size:.6rem;color:#bbb;text-align:center;padding-top:3px">…还有${nodes.length - 3}个节点</div>` : ''}</div>` : ''}
    </div>`;
  }

  // 催款任务预览
  let collectHtml = '';
  const tasks = p.collectTasks || [];
  if (colKey === 'c' && tasks.length && p.stage === STAGE.NEGOTIATING) {
    const shown = tasks.filter(t => !t.done).slice(0, 3);
    collectHtml = `<div class="card-collect-preview">` +
      shown.map(t => `
      <div class="collect-mini">
        <div class="collect-mini-chk ${t.done ? 'done' : ''}"></div>
        <span style="color:var(--sc);font-weight:600">${t.date || '—'}</span>
        ${t.amount ? `<span>催 ${t.amount}万</span>` : ''}
        ${t.note   ? `<span style="color:#aaa">·${esc(t.note)}</span>` : ''}
      </div>`).join('') +
      (tasks.filter(t => !t.done).length > 3 ? `<div style="font-size:.6rem;color:#bbb">…还有更多</div>` : '') +
      `</div>`;
  }

  const descHtml    = p.desc      ? `<div class="card-desc">${esc(p.desc)}</div>`         : '';
  const updatedHtml = p.updatedAt ? `<div class="card-updated">🕐 ${p.updatedAt}</div>`   : '';
  const logHtml     = '';

  const todosShown = (p.todos || []).slice(0, 3);
  const todoHtml   = todosShown.length ? `
    <div class="todos-preview">
      ${todosShown.map(t => `
        <div class="todo-item-mini ${t.done ? 'done' : ''}">
          <div class="chk-mini ${t.done ? 'checked' : ''}"></div>
          <span>${esc(t.text)}</span>
        </div>`).join('')}
      ${(p.todos || []).length > 3 ? `<div style="font-size:.6rem;color:#bbb">…还有${p.todos.length - 3}项</div>` : ''}
    </div>` : '';

  let actionBtns = '';
  if (p.stage === STAGE.NEGOTIATING) actionBtns += `<button class="btn-sm btn-next" onclick="moveStage('${p.id}',${STAGE.DELIVERING})">→ 已签单执行中</button>`;
  if (p.stage === STAGE.DELIVERING)  actionBtns += `<button class="btn-sm btn-done" onclick="moveStage('${p.id}',${STAGE.COMPLETED})">→ 已完结</button>`;
  actionBtns += `<button class="btn-sm btn-del" onclick="deleteProject('${p.id}')">✕</button>`;

  const html = `
  <div class="card" data-s="${sAttr}">
    <div class="card-top">
      <div class="card-name" onclick="editProject('${p.id}')">${esc(p.name)}</div>
      <span class="card-active ${p.active === 'inactive' ? 'off' : 'on'}">${p.active === 'inactive' ? '🔴 不活跃' : '🟢 活跃'}</span>
    </div>
    ${updatedHtml}${logHtml}${metaHtml}${amtHtml}${deliveryHtml}${paymentHtml}${descHtml}${todoHtml}
    <div class="card-actions">${actionBtns}</div>
  </div>`;

  renderCache.set(cacheKey, html);
  return html;
}

// ── 侧边栏 ────────────────────────────────────────
function toggleSidebar() {
  const sb  = document.getElementById('sidebar');
  const btn = sb.querySelector('.sb-toggle');
  sb.classList.toggle('collapsed');
  const collapsed = sb.classList.contains('collapsed');
  btn.textContent = collapsed ? '▶' : '◀';
  try { localStorage.setItem(STORAGE_KEY.SB_COLLAPSED, collapsed ? '1' : '0'); } catch(e) {}
}

function initSidebar() {
  try {
    if (localStorage.getItem(STORAGE_KEY.SB_COLLAPSED) === '1') {
      const sb  = document.getElementById('sidebar');
      const btn = sb?.querySelector('.sb-toggle');
      if (sb)  sb.classList.add('collapsed');
      if (btn) btn.textContent = '▶';
    }
  } catch(e) {}
}

// ── 缓存管理 ──────────────────────────────────────
function clearRenderCache() {
  renderCache.clear();
}

// ── refreshView() ─────────────────────────────────
// 清缓存 → 重渲染看板 → 按需刷新侧边面板。
// 调用方不需要关心面板是否打开，统一走这里。
function refreshView() {
  clearRenderCache();
  render();
  if (document.getElementById('todosPanel').classList.contains('open'))  renderTodosPanel();
  if (document.getElementById('ledgerPanel').classList.contains('open')) renderLedger();
}

// ── 导出 ──────────────────────────────────────────
export {
  render,
  updateStats,
  cardHTML,
  toggleSidebar,
  initSidebar,
  clearRenderCache,
  refreshView
};
